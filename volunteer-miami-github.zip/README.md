# Volunteer Opportunities – UM Internal Medicine Residency

Static, single-file website (`index.html`). No build step.

## Publish with GitHub Pages
1. Create a new **public** repository (suggested name: `volunteer-miami`).
2. Upload `index.html`, `.nojekyll` and `README.md` (Add file → Upload files).
3. Settings → Pages → Source: **Deploy from a branch** → Branch: `main`, folder `/ (root)` → Save.
4. After about a minute the site is live at `https://<username>.github.io/<repo>/`.

## Updating
Edit `index.html` on GitHub (pencil icon). Events are in the `E` array, ongoing items in the `O` array, and the food distribution card in `FD`. Commit and the site updates automatically.

## Suggestions form
Submissions open the visitor's email app addressed to `jaf3467@miami.edu` (change the `LIAISON` constant to redirect).
